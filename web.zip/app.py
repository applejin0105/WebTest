from flask import Flask, render_template, request, redirect, jsonify
from pymongo import MongoClient
from bson.objectid import ObjectId

app = Flask(__name__)

# DB 연결
client = MongoClient('mongodb://admin:1945@54.180.25.92:27017/')
db = client.dbjungle
memos_collection = db.memos

# 메모장 메인
@app.route('/')
def home():
    return render_template("index.html")

# JSON으로 메모 가져오기
@app.route('/memos', methods=['GET'])
def get_memos():
    memos = list(memos_collection.find({}, {"_id": 1, "title": 1, "content": 1, "likes": 1}))
    for memo in memos:
        memo['_id'] = str(memo['_id'])
    return jsonify(memos)

# 메모 추가 API
@app.route('/add_memo', methods=['POST'])
def add_memo():
    title = request.form['title']
    content = request.form['content']
    memos_collection.insert_one({"title": title, "content": content, "likes": 0})
    return jsonify({"message": "메모 추가 완료"})

# 메모 삭제 API
@app.route('/delete_memo/<memo_id>', methods=['GET'])
def delete_memo(memo_id):
    memos_collection.delete_one({"_id": ObjectId(memo_id)})
    return jsonify({"message": "메모 삭제 완료"})

# 좋아요 증가 API
@app.route('/like_memo/<memo_id>', methods=['GET'])
def like_memo(memo_id):
    memos_collection.update_one({"_id": ObjectId(memo_id)}, {"$inc": {"likes": 1}})
    return jsonify({"message": "좋아요 증가 완료"})

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)