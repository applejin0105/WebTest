document.addEventListener("DOMContentLoaded", function () {
    loadMemos();
});

function loadMemos() {
    fetch("/memos")
        .then(response => response.json())
        .then(memos => {
            const memoContainer = document.getElementById("memoContainer");
            memoContainer.innerHTML = "";
            memos.forEach(memo => {
                const memoElement = document.createElement("div");
                memoElement.classList.add("card", "memo-card", "p-3", "mb-2");
                memoElement.innerHTML = `
                    <h5>${memo.title}</h5>
                    <p>${memo.content}</p>
                    <button class="btn btn-danger btn-sm" onclick="deleteMemo('${memo._id}')">삭제</button>
                    <button class="btn btn-success btn-sm" onclick="likeMemo('${memo._id}')">좋아요 (${memo.likes})</button>
                `;
                memoContainer.appendChild(memoElement);
            });
        });
}

function saveMemo() {
    const title = document.getElementById("title").value;
    const content = document.getElementById("content").value;
    
    fetch("/add_memo", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ title, content })
    })
    .then(() => {
        document.getElementById("title").value = "";
        document.getElementById("content").value = "";
        loadMemos();
    });
}

function deleteMemo(memoId) {
    fetch(`/delete_memo/${memoId}`, { method: "GET" })
    .then(() => loadMemos());
}

function likeMemo(memoId) {
    fetch(`/like_memo/${memoId}`, { method: "GET" })
    .then(() => loadMemos());
}